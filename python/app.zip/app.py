from flask import Flask, request, jsonify
from flask_cors import CORS
import openai, os
from dotenv import load_dotenv
import asyncio
from openai import OpenAI

# Importing necessary modules for RAG chatbot
from langchain_openai import OpenAIEmbeddings
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI
from langchain.chains.question_answering import load_qa_chain

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for communication with React

# Load environment variables
load_dotenv()
# os.environ["OPENAI_API_KEY"] = ("sk-proj-HQED69W8dwiAK3lBEY73T3BlbkFJSh7wcg3jLDUqS2u6jJ8V")
# Set OpenAI API key from environment variables
openai_api_key = os.getenv("COMPARISON_OPENAI_API_KEY")
print("openai_api_key",openai_api_key)
client = OpenAI(api_key=openai_api_key)
#openai.api_key = openai_api_key
# Prompt template for RAG chatbot
prompt_template = """Use the following pieces of context to answer the question at the end. 
If you don't know the answer, just say that you don't know. Don't try to make up an answer.

{context}

Question: {question}
Answer:"""
prompt = PromptTemplate(
    template=prompt_template, input_variables=["context", "question"]
)

embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",
    api_key=openai_api_key
)

UPLOAD_FOLDER = "temp/"  # Directory for uploaded files
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Global variable for RAG chatbot vector store
db = None


# --------- Normal Chatbot Endpoint ---------
@app.route("/normal-chat", methods=["POST"])
def normal_chat():
    data = request.json
    user_input = data.get("message")

    if not user_input:
        return jsonify({"error": "No message provided"}), 400

    messages = [
        {"role": "user", "content": user_input}
    ]  # Create user message for OpenAI

    # Call OpenAI API for response
    response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=messages,
    max_tokens=150
)

    # Extract chatbot response
    chatbot_response = response.choices[0].message.content

    return jsonify({"response": chatbot_response})

# Run the Flask app
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=True)